// Role switch
const studentTab = document.getElementById("studentTab");
const facultyTab = document.getElementById("facultyTab");
const roleTitle = document.getElementById("roleTitle");

studentTab.onclick = () => {
  roleTitle.innerText = "Student Login";
  studentTab.classList.add("active");
  facultyTab.classList.remove("active");
};
facultyTab.onclick = () => {
  roleTitle.innerText = "Faculty Login";
  facultyTab.classList.add("active");
  studentTab.classList.remove("active");
};

// Show/hide password
const password = document.getElementById("password");
const togglePassword = document.getElementById("togglePassword");
togglePassword.onclick = () => {
  password.type = password.type === "password" ? "text" : "password";
};

// Caps Lock detection
const capsWarning = document.getElementById("capsWarning");
password.addEventListener("keyup", (e) => {
  capsWarning.style.display = e.getModifierState("CapsLock") ? "block" : "none";
});

// Password strength meter
const strengthMeter = document.getElementById("strengthMeter").querySelector("span");
password.addEventListener("input", () => {
  let val = password.value;
  let strength = 0;
  if (val.match(/[a-z]/)) strength++;
  if (val.match(/[A-Z]/)) strength++;
  if (val.match(/[0-9]/)) strength++;
  if (val.match(/[^a-zA-Z0-9]/)) strength++;
  if (val.length >= 8) strength++;

  let colors = ["red", "orange", "yellow", "blue", "green"];
  strengthMeter.style.width = (strength * 20) + "%";
  strengthMeter.style.background = colors[strength - 1] || "transparent";
});

// Remember me
const email = document.getElementById("email");
const rememberMe = document.getElementById("rememberMe");

window.onload = () => {
  if (localStorage.getItem("rememberEmail")) {
    email.value = localStorage.getItem("rememberEmail");
    rememberMe.checked = true;
  }
};

document.getElementById("loginForm").addEventListener("submit", (e) => {
  e.preventDefault();
  if (rememberMe.checked) {
    localStorage.setItem("rememberEmail", email.value);
  } else {
    localStorage.removeItem("rememberEmail");
  }
  showToast("✅ Login Successful!");
});

// Dark mode
const darkToggle = document.getElementById("darkModeToggle");
darkToggle.onclick = () => {
  document.body.classList.toggle("dark");
  localStorage.setItem("darkMode", document.body.classList.contains("dark"));
};
if (localStorage.getItem("darkMode") === "true") {
  document.body.classList.add("dark");
}

// Toast notification
function showToast(message) {
  const toast = document.getElementById("toast");
  toast.innerText = message;
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 3000);
}
